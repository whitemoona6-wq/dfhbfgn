# Нагрузочное тестирование и оптимизация GameGear

## Объём данных после наполнения

| Таблица       | Строк  |
|---------------|--------|
| users         | 1 500  |
| products      | 2 500  |
| orders        | 2 000  |
| order_items   | ~6 000 |
| reviews       | 5 000  |
| cart          | 2 000  |
| audit_log     | 5 000  |

Скрипт: `python3 bench_and_optimize.py` (можно запускать повторно — идемпотентен).

## Бенчмарки (медиана, 20 прогонов)

| Запрос                         | До индексов | После      | Ускорение |
|--------------------------------|-------------|------------|-----------|
| index top 8 by rating          | 0.32 ms     | 0.02 ms    | **14×**   |
| reviews JOIN users             | 0.13 ms     | 0.01 ms    | **14×**   |
| products stock < 10 COUNT      | 0.11 ms     | 0.01 ms    | **19×**   |
| audit login_fail 24h COUNT     | 0.33 ms     | 0.03 ms    | **10×**   |
| admin audit LIMIT 100          | 1.32 ms     | 0.16 ms    | **8×**    |
| admin orders LIMIT 50          | 0.54 ms     | 0.08 ms    | **7×**    |
| SELECT DISTINCT brand          | 0.70 ms     | 0.11 ms    | **6×**    |
| catalog brand filter           | 0.67 ms     | 0.48 ms    | 1.4×      |
| catalog all ORDER BY rating    | 8.25 ms     | 6.99 ms    | 1.2×      |
| **FTS5 MATCH 'Logitech'**      | (не было)   | **0.40 ms**| vs LIKE ~1.0–1.4 ms |

LIKE `%term%` по-прежнему full scan; для поиска в UI используется **FTS5**.

## Что сделано

### 1. Индексы (в `database.ensure_indexes`, вызывается из `init_db`)

- `products`: category_id, brand, rating, price, name, stock  
- `reviews`: product_id, user_id, created_at  
- `orders`: user_id, created_at, status  
- `order_items`: order_id, product_id  
- `cart`: user_id, product_id  
- `audit_log`: created_at, action, user_id, (action, created_at)  
- `users`: locked_until, is_active  

### 2. FTS5 полнотекстовый поиск

Таблица `products_fts` + триггеры синхронизации.  
Каталог (`routes/main.py`) при наличии `q=` использует `MATCH` вместо `LIKE '%…%'`.

### 3. PRAGMA производительности

В `get_db()`:

- `journal_mode=WAL`
- `synchronous=NORMAL`
- `temp_store=MEMORY`
- `cache_size≈32MB`

### 4. Код приложения

- `cart_count` в context processor кэшируется в `g` на время одного HTTP-запроса.
- Модуль `query_optimized.py` — helper для каталога с FTS.

## Рекомендации дальше

1. **Admin page** — ~15 отдельных запросов; объединить stats в один SELECT или кэшировать на 30–60 с.  
2. **Pagination** на `/catalog` при росте >10k товаров (сейчас отдаётся весь результат).  
3. Production: connection-per-request через `g.db` + `teardown_appcontext`, или переход на PostgreSQL.  
4. Повторный прогон: `python3 bench_and_optimize.py`.

## Быстрая проверка

```bash
cd gaming_shop
python3 -c "from database import init_db; init_db(); print('indexes ok')"
python3 bench_and_optimize.py   # seed + before/after numbers
```
