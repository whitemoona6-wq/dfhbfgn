"""Payment provider abstraction.

Modes
-----
- mock (default): local simulation, no network — for dev/tests
- yookassa: real HTTP API (needs YOOKASSA_SHOP_ID + YOOKASSA_SECRET_KEY)

Env
---
PAYMENT_PROVIDER=mock|yookassa
YOOKASSA_SHOP_ID=...
YOOKASSA_SECRET_KEY=...
PAYMENT_RETURN_URL=http://127.0.0.1:5000/payment/return
PAYMENT_WEBHOOK_SECRET=optional shared secret for webhook HMAC
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import secrets
import uuid
from dataclasses import dataclass
from typing import Any, Optional
from urllib import error, request

logger = logging.getLogger(__name__)


@dataclass
class PaymentResult:
    ok: bool
    payment_id: str
    status: str  # pending | waiting_for_capture | succeeded | canceled | failed
    confirmation_url: Optional[str] = None
    raw: Optional[dict] = None
    error: Optional[str] = None


class BasePaymentProvider:
    name = "base"

    def create_payment(
        self,
        *,
        order_id: int,
        amount: float,
        description: str,
        return_url: str,
        metadata: Optional[dict] = None,
    ) -> PaymentResult:
        raise NotImplementedError

    def get_payment(self, payment_id: str) -> PaymentResult:
        raise NotImplementedError

    def verify_webhook(self, body: bytes, headers: dict) -> bool:
        """Return True if webhook authenticity is acceptable."""
        return True

    def parse_webhook(self, body: bytes) -> dict[str, Any]:
        """Normalize webhook payload to {event, payment_id, status, order_id?}."""
        return {}


class MockPaymentProvider(BasePaymentProvider):
    """In-memory / deterministic mock for local development."""

    name = "mock"
    _store: dict[str, dict] = {}

    def create_payment(
        self,
        *,
        order_id: int,
        amount: float,
        description: str,
        return_url: str,
        metadata: Optional[dict] = None,
    ) -> PaymentResult:
        pid = f"mock_{uuid.uuid4().hex[:16]}"
        conf_url = f"{return_url}?payment_id={pid}&order_id={order_id}&mock=1"
        data = {
            "id": pid,
            "status": "pending",
            "amount": amount,
            "order_id": order_id,
            "description": description,
            "confirmation_url": conf_url,
            "metadata": metadata or {},
        }
        self._store[pid] = data
        return PaymentResult(
            ok=True,
            payment_id=pid,
            status="pending",
            confirmation_url=conf_url,
            raw=data,
        )

    def get_payment(self, payment_id: str) -> PaymentResult:
        data = self._store.get(payment_id)
        if not data:
            return PaymentResult(ok=False, payment_id=payment_id, status="failed", error="not found")
        return PaymentResult(
            ok=True,
            payment_id=payment_id,
            status=data["status"],
            confirmation_url=data.get("confirmation_url"),
            raw=data,
        )

    def mark_succeeded(self, payment_id: str) -> PaymentResult:
        data = self._store.get(payment_id)
        if not data:
            return PaymentResult(ok=False, payment_id=payment_id, status="failed", error="not found")
        data["status"] = "succeeded"
        return self.get_payment(payment_id)

    def verify_webhook(self, body: bytes, headers: dict) -> bool:
        secret = os.environ.get("PAYMENT_WEBHOOK_SECRET", "")
        if not secret:
            return True  # mock accepts all when secret not set
        sig = headers.get("X-Payment-Signature") or headers.get("x-payment-signature") or ""
        expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, sig)

    def parse_webhook(self, body: bytes) -> dict[str, Any]:
        data = json.loads(body.decode("utf-8"))
        return {
            "event": data.get("event", "payment.updated"),
            "payment_id": data.get("payment_id") or data.get("object", {}).get("id"),
            "status": data.get("status") or data.get("object", {}).get("status"),
            "order_id": data.get("order_id")
            or (data.get("object", {}).get("metadata") or {}).get("order_id"),
        }


class YooKassaProvider(BasePaymentProvider):
    """Minimal YooKassa Payments API client (create + get + webhook parse)."""

    name = "yookassa"
    API = "https://api.yookassa.ru/v3"

    def __init__(self):
        self.shop_id = os.environ.get("YOOKASSA_SHOP_ID", "")
        self.secret = os.environ.get("YOOKASSA_SECRET_KEY", "")
        if not self.shop_id or not self.secret:
            raise RuntimeError("YOOKASSA_SHOP_ID and YOOKASSA_SECRET_KEY required")

    def _request(self, method: str, path: str, payload: Optional[dict] = None) -> dict:
        url = f"{self.API}{path}"
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("Idempotence-Key", secrets.token_hex(16))
        import base64

        token = base64.b64encode(f"{self.shop_id}:{self.secret}".encode()).decode()
        req.add_header("Authorization", f"Basic {token}")
        try:
            with request.urlopen(req, timeout=20) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            logger.error("YooKassa HTTP %s: %s", e.code, body)
            raise

    def create_payment(
        self,
        *,
        order_id: int,
        amount: float,
        description: str,
        return_url: str,
        metadata: Optional[dict] = None,
    ) -> PaymentResult:
        meta = dict(metadata or {})
        meta["order_id"] = str(order_id)
        payload = {
            "amount": {"value": f"{amount:.2f}", "currency": "RUB"},
            "confirmation": {"type": "redirect", "return_url": return_url},
            "capture": True,
            "description": description[:128],
            "metadata": meta,
        }
        try:
            data = self._request("POST", "/payments", payload)
        except Exception as e:
            return PaymentResult(
                ok=False, payment_id="", status="failed", error=str(e),
            )
        conf = (data.get("confirmation") or {}).get("confirmation_url")
        return PaymentResult(
            ok=True,
            payment_id=data.get("id", ""),
            status=data.get("status", "pending"),
            confirmation_url=conf,
            raw=data,
        )

    def get_payment(self, payment_id: str) -> PaymentResult:
        try:
            data = self._request("GET", f"/payments/{payment_id}")
        except Exception as e:
            return PaymentResult(
                ok=False, payment_id=payment_id, status="failed", error=str(e),
            )
        conf = (data.get("confirmation") or {}).get("confirmation_url")
        return PaymentResult(
            ok=True,
            payment_id=data.get("id", payment_id),
            status=data.get("status", "unknown"),
            confirmation_url=conf,
            raw=data,
        )

    def verify_webhook(self, body: bytes, headers: dict) -> bool:
        # YooKassa does not sign webhooks the same way; optionally restrict by IP in nginx.
        # Optional HMAC if PAYMENT_WEBHOOK_SECRET is set (custom proxy).
        secret = os.environ.get("PAYMENT_WEBHOOK_SECRET", "")
        if not secret:
            return True
        sig = headers.get("X-Payment-Signature") or headers.get("x-payment-signature") or ""
        expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, sig)

    def parse_webhook(self, body: bytes) -> dict[str, Any]:
        data = json.loads(body.decode("utf-8"))
        obj = data.get("object") or {}
        meta = obj.get("metadata") or {}
        return {
            "event": data.get("event", "payment.updated"),
            "payment_id": obj.get("id"),
            "status": obj.get("status"),
            "order_id": meta.get("order_id"),
        }


def get_payment_provider() -> BasePaymentProvider:
    name = (os.environ.get("PAYMENT_PROVIDER") or "mock").strip().lower()
    if name == "yookassa":
        return YooKassaProvider()
    return MockPaymentProvider()
