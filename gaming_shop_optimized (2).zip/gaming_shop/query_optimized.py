"""Optimized query helpers (FTS search, shared patterns)."""
from database import get_db


def catalog_search(search: str | None, category_slug: str | None, brand: str | None, sort: str):
    """Catalog with FTS5 when search is present, else classic filters."""
    conn = get_db()
    params = []
    if search:
        # FTS5: phrase / prefix
        q = """
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products_fts f
            JOIN products p ON p.id = f.rowid
            JOIN categories c ON p.category_id = c.id
            WHERE products_fts MATCH ?
        """
        # Escape FTS special chars simply
        term = search.replace('"', ' ').strip()
        if not term:
            term = '""'
        else:
            # prefix search for partial match
            parts = [f'"{p}"*' if len(p) > 1 else p for p in term.split() if p]
            term = " ".join(parts) if parts else '""'
        params.append(term)
    else:
        q = """
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p JOIN categories c ON p.category_id = c.id
            WHERE 1=1
        """

    if category_slug:
        q += " AND c.slug = ?"
        params.append(category_slug)
    if brand:
        q += " AND p.brand = ?"
        params.append(brand)

    sort_map = {
        "price_asc": " ORDER BY p.price ASC",
        "price_desc": " ORDER BY p.price DESC",
        "name": " ORDER BY p.name ASC",
    }
    q += sort_map.get(sort, " ORDER BY p.rating DESC")

    products = conn.execute(q, params).fetchall()
    categories = conn.execute("SELECT * FROM categories").fetchall()
    brands = conn.execute("SELECT DISTINCT brand FROM products ORDER BY brand").fetchall()
    conn.close()
    return products, categories, brands
