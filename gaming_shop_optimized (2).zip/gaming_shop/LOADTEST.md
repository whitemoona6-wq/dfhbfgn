# Нагрузочные тесты и оптимизация GameGear

## Как запускать

```bash
cd gaming_shop
pip install flask flask-login

# 1) Наполнить БД + индексы + SQL-бенчмарк до/после
python3 bench_and_optimize.py

# 2) HTTP + SQL + EXPLAIN + отчёт по тормозам
python3 load_test.py

# Опции:
python3 load_test.py --sql-only
python3 load_test.py --http-only
python3 load_test.py --workers 12 --requests 50 --repeats 20
python3 load_test.py --keep-db-path
```

По умолчанию БД копируется в /tmp (на сетевых дисках SQLite close() может быть очень медленным).

## Данные: 1500 users, 2500 products, 2000 orders, 5000 reviews

## Результаты после оптимизации

HTTP sequential: /catalog ~3.6 ms (было ~740 ms), /product ~1.6 ms  
HTTP concurrent (6 workers): /catalog ~260 RPS, /product ~550 RPS  
SQL: FTS search ~0.4 ms, admin queries <0.2 ms

## Тормоза → фиксы

1. Нет индексов → 22 B-tree + FTS5
2. LIKE '%x%' → FTS5 MATCH
3. 2500 карточек в HTML → пагинация 24/стр
4. WAL PRAGMA на каждый get_db → один раз в init_db
5. cart_count каждый HTML → кэш в flask.g

## Файлы

- load_test.py — замер скорости, EXPLAIN, отчёт
- bench_and_optimize.py — seed + SQL before/after
