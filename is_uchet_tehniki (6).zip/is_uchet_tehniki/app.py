#!/usr/bin/env python3
"""
ИС «Учёт техники» — веб-приложение с SQLite
Запуск: python app.py
http://127.0.0.1:5000
"""

from flask import (
    Flask, send_from_directory, request, jsonify,
    send_file, session, redirect
)
from functools import wraps
import os
import sqlite3
import json
import shutil
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'uchet_tehniki.db'
BACKUP_DIR = BASE_DIR / 'backups'
BACKUP_DIR.mkdir(exist_ok=True)

app = Flask(__name__, static_folder=str(BASE_DIR), static_url_path='')
app.secret_key = 'iteup-uchet-tehniki-2026-secret'


# ---------- DB helpers ----------

def get_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.executescript('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        login TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        fio TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        created TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS responsible (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fio TEXT NOT NULL,
        position TEXT NOT NULL,
        cabinet TEXT,
        phone TEXT,
        email TEXT
    );

    CREATE TABLE IF NOT EXISTS equipment (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inv_num TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        model TEXT,
        serial TEXT,
        type TEXT NOT NULL,
        cabinet TEXT NOT NULL,
        responsible TEXT,
        purchase_date TEXT,
        cost REAL DEFAULT 0,
        status TEXT NOT NULL,
        last_to TEXT,
        note TEXT
    );

    CREATE TABLE IF NOT EXISTS maintenance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL,
        inv_num TEXT NOT NULL,
        type TEXT NOT NULL,
        description TEXT NOT NULL,
        executor TEXT,
        result TEXT,
        cost REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS backup_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        created TEXT NOT NULL,
        equipment_count INTEGER,
        maintenance_count INTEGER,
        size_bytes INTEGER
    );
    ''')

    # seed admin if empty
    row = c.execute('SELECT COUNT(*) AS n FROM users').fetchone()
    if row['n'] == 0:
        c.execute(
            'INSERT INTO users (login, password, fio, role, created) VALUES (?,?,?,?,?)',
            ('admin', 'admin123', 'Администратор системы', 'admin', '2026-01-01')
        )

    # seed demo data if equipment empty
    row = c.execute('SELECT COUNT(*) AS n FROM equipment').fetchone()
    if row['n'] == 0:
        seed_demo(c)

    conn.commit()
    conn.close()


def seed_demo(c):
    responsible = [
        ('Смирнов Артём Владимирович', 'Системный администратор', 'Серверная', '+7 (912) 111-00-11', 'smirnov@iteup.ru'),
        ('Кузнецова Мария Александровна', 'Преподаватель, зав. кабинетом', 'Каб. 101', '+7 (912) 222-00-22', 'kuznetsova@iteup.ru'),
        ('Новиков Игорь Сергеевич', 'Преподаватель, зав. кабинетом', 'Каб. 102', '+7 (912) 333-00-33', 'novikov@iteup.ru'),
        ('Волкова Ольга Дмитриевна', 'Преподаватель, зав. кабинетом', 'Каб. 205', '+7 (912) 444-00-44', 'volkova@iteup.ru'),
        ('Соколов Павел Андреевич', 'Преподаватель, зав. кабинетом', 'Каб. 203', '+7 (912) 555-00-55', 'sokolov@iteup.ru'),
        ('Шадрина Арина Юрьевна', 'Руководитель практики', 'Администрация', '+7 (912) 666-00-66', 'shadrina@iteup.ru'),
    ]
    c.executemany(
        'INSERT INTO responsible (fio, position, cabinet, phone, email) VALUES (?,?,?,?,?)',
        responsible
    )

    equipment = [
        ('Т-001', 'ПК DEXP Aquilon', 'Aquilon O230', 'SN001234', 'ПК', 'Каб. 101', 'Кузнецова М.А.', '2023-09-01', 45000, 'В эксплуатации', '2026-03-15', ''),
        ('Т-002', 'ПК DEXP Aquilon', 'Aquilon O230', 'SN001235', 'ПК', 'Каб. 101', 'Кузнецова М.А.', '2023-09-01', 45000, 'В эксплуатации', '2026-03-15', ''),
        ('Т-003', 'ПК DEXP Aquilon', 'Aquilon O230', 'SN001236', 'ПК', 'Каб. 102', 'Новиков И.С.', '2023-09-01', 45000, 'В эксплуатации', '2026-02-20', ''),
        ('Т-004', 'ПК DEXP Aquilon', 'Aquilon O230', 'SN001237', 'ПК', 'Каб. 101', 'Кузнецова М.А.', '2023-09-01', 45000, 'В ремонте', '2025-11-10', 'Не включается БП'),
        ('Т-005', 'Ноутбук ASUS', 'VivoBook 15', 'ASU98765', 'Ноутбук', 'Каб. 205', 'Волкова О.Д.', '2024-01-15', 52000, 'В эксплуатации', '2026-04-01', ''),
        ('Т-006', 'Ноутбук Lenovo', 'IdeaPad 3', 'LEN54321', 'Ноутбук', 'Каб. 205', 'Волкова О.Д.', '2024-01-15', 48000, 'В эксплуатации', '2026-04-01', ''),
        ('Т-007', 'Проектор Epson', 'EB-X51', 'EPX11223', 'Проектор', 'Каб. 101', 'Кузнецова М.А.', '2022-08-20', 38000, 'В эксплуатации', '2025-12-05', ''),
        ('Т-008', 'Интерактивная доска', 'Smart Board 600', 'SB600998', 'Интерактивная доска', 'Каб. 102', 'Новиков И.С.', '2021-05-10', 95000, 'В эксплуатации', '2026-01-20', ''),
        ('Т-009', 'Коммутатор Cisco', 'SG350-28', 'CSG350001', 'Сетевое оборудование', 'Серверная', 'Смирнов А.В.', '2022-03-01', 65000, 'В эксплуатации', '2025-10-15', ''),
        ('Т-010', 'Сервер Dell T140', 'PowerEdge T140', 'DELLT14001', 'Сервер', 'Серверная', 'Смирнов А.В.', '2021-11-20', 120000, 'В эксплуатации', '2026-05-10', 'Основной сервер'),
        ('Т-011', 'ПК DEXP Aquilon', 'Aquilon O230', 'SN001240', 'ПК', 'Каб. 203', 'Соколов П.А.', '2023-09-01', 45000, 'На складе', '', 'Резерв'),
        ('Т-012', 'Принтер HP', 'LaserJet Pro M404', 'HPM40455', 'Периферия', 'Каб. 102', 'Новиков И.С.', '2023-02-14', 22000, 'В эксплуатации', '2025-09-01', ''),
        ('Т-013', 'МФУ Canon', 'i-SENSYS MF443', 'CNMF44312', 'Периферия', 'Каб. 205', 'Волкова О.Д.', '2022-06-30', 35000, 'В эксплуатации', '2026-02-28', ''),
        ('Т-014', 'Ноутбук HP', 'ProBook 450', 'HPPB45077', 'Ноутбук', 'Каб. 203', 'Соколов П.А.', '2020-09-01', 42000, 'В ремонте', '2025-08-12', 'Проблемы с батареей'),
        ('Т-015', 'Веб-камера Logitech', 'C920', 'LOGC92099', 'Периферия', 'Каб. 102', 'Новиков И.С.', '2019-04-10', 7500, 'Списано', '', 'Неисправна, списана 2025-06'),
    ]
    c.executemany(
        '''INSERT INTO equipment
           (inv_num, name, model, serial, type, cabinet, responsible, purchase_date, cost, status, last_to, note)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
        equipment
    )

    maintenance = [
        ('2026-05-10', 'Т-010', 'ТО', 'Плановое ТО: чистка, проверка дисков, обновление ПО', 'Смирнов А.В.', 'Исправно', 0),
        ('2026-04-01', 'Т-005', 'ТО', 'Чистка системы охлаждения, обновление драйверов', 'Смирнов А.В.', 'Исправно', 0),
        ('2026-04-01', 'Т-006', 'ТО', 'Чистка системы охлаждения', 'Смирнов А.В.', 'Исправно', 0),
        ('2026-03-15', 'Т-001', 'ТО', 'Плановое ТО кабинета 101', 'Смирнов А.В.', 'Исправно', 0),
        ('2026-03-15', 'Т-002', 'ТО', 'Плановое ТО кабинета 101', 'Смирнов А.В.', 'Исправно', 0),
        ('2026-02-28', 'Т-013', 'Ремонт', 'Замена картриджа и ролика захвата', 'Сервис-центр', 'Исправно', 4500),
        ('2025-11-12', 'Т-004', 'Диагностика', 'Не включается. Диагностика БП — неисправен', 'Смирнов А.В.', 'Требует ремонта', 0),
        ('2025-08-15', 'Т-014', 'Ремонт', 'Замена батареи ноутбука', 'Сервис-центр', 'Исправно', 6200),
    ]
    c.executemany(
        '''INSERT INTO maintenance
           (date, inv_num, type, description, executor, result, cost)
           VALUES (?,?,?,?,?,?,?)''',
        maintenance
    )


def row_to_dict(row):
    return dict(row) if row else None


def rows_to_list(rows):
    return [dict(r) for r in rows]


# ---------- Auth ----------

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get('user'):
            return jsonify({'error': 'unauthorized'}), 401
        return f(*args, **kwargs)
    return wrapped


def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        user = session.get('user')
        if not user or user.get('role') != 'admin':
            return jsonify({'error': 'forbidden'}), 403
        return f(*args, **kwargs)
    return wrapped


# ---------- Pages ----------

@app.route('/')
def index():
    return send_from_directory(str(BASE_DIR), 'index.html')


@app.route('/<path:path>')
def static_files(path):
    # don't serve db/backups as static by mistake for sensitive paths
    if path.endswith('.db') or path.startswith('backups/'):
        return jsonify({'error': 'forbidden'}), 403
    return send_from_directory(str(BASE_DIR), path)


# ---------- API: Auth ----------

@app.route('/api/login', methods=['POST'])
def api_login():
    body = request.get_json(force=True) or {}
    login = (body.get('login') or '').strip().lower()
    password = body.get('password') or ''
    conn = get_db()
    user = conn.execute(
        'SELECT id, login, fio, role FROM users WHERE lower(login)=? AND password=?',
        (login, password)
    ).fetchone()
    conn.close()
    if not user:
        return jsonify({'error': 'Неверный логин или пароль'}), 401
    u = row_to_dict(user)
    session['user'] = u
    return jsonify({'user': u})


@app.route('/api/register', methods=['POST'])
def api_register():
    body = request.get_json(force=True) or {}
    fio = (body.get('fio') or '').strip()
    login = (body.get('login') or '').strip().lower()
    password = body.get('password') or ''
    if not fio or not login or len(password) < 6:
        return jsonify({'error': 'Заполните все поля (пароль от 6 символов)'}), 400
    conn = get_db()
    exists = conn.execute('SELECT id FROM users WHERE lower(login)=?', (login,)).fetchone()
    if exists:
        conn.close()
        return jsonify({'error': 'Логин уже занят'}), 400
    created = datetime.now().strftime('%Y-%m-%d')
    cur = conn.execute(
        'INSERT INTO users (login, password, fio, role, created) VALUES (?,?,?,?,?)',
        (login, password, fio, 'user', created)
    )
    conn.commit()
    uid = cur.lastrowid
    user = {'id': uid, 'login': login, 'fio': fio, 'role': 'user'}
    session['user'] = user
    conn.close()
    return jsonify({'user': user})


@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.pop('user', None)
    return jsonify({'ok': True})


@app.route('/api/me')
def api_me():
    user = session.get('user')
    if not user:
        return jsonify({'user': None})
    return jsonify({'user': user})


# ---------- API: Data dump for frontend compatibility ----------

@app.route('/api/data')
@login_required
def api_data():
    conn = get_db()
    equipment = rows_to_list(conn.execute(
        '''SELECT id, inv_num AS invNum, name, model, serial, type, cabinet,
                  responsible, purchase_date AS purchaseDate, cost, status,
                  last_to AS lastTO, note FROM equipment ORDER BY id'''
    ).fetchall())
    responsible = rows_to_list(conn.execute(
        'SELECT id, fio, position, cabinet, phone, email FROM responsible ORDER BY id'
    ).fetchall())
    maintenance = rows_to_list(conn.execute(
        '''SELECT id, date, inv_num AS invNum, type, description, executor, result, cost
           FROM maintenance ORDER BY date DESC'''
    ).fetchall())
    users = []
    if session['user'].get('role') == 'admin':
        users = rows_to_list(conn.execute(
            'SELECT id, login, fio, role, created FROM users ORDER BY id'
        ).fetchall())
    conn.close()
    return jsonify({
        'equipment': equipment,
        'responsible': responsible,
        'maintenance': maintenance,
        'users': users
    })


# ---------- API: Equipment ----------

@app.route('/api/equipment', methods=['GET', 'POST'])
@login_required
def api_equipment():
    conn = get_db()
    if request.method == 'GET':
        rows = rows_to_list(conn.execute(
            '''SELECT id, inv_num AS invNum, name, model, serial, type, cabinet,
                      responsible, purchase_date AS purchaseDate, cost, status,
                      last_to AS lastTO, note FROM equipment ORDER BY id'''
        ).fetchall())
        conn.close()
        return jsonify(rows)

    if session['user'].get('role') != 'admin':
        conn.close()
        return jsonify({'error': 'forbidden'}), 403

    b = request.get_json(force=True) or {}
    try:
        cur = conn.execute(
            '''INSERT INTO equipment
               (inv_num, name, model, serial, type, cabinet, responsible,
                purchase_date, cost, status, last_to, note)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''',
            (
                b.get('invNum'), b.get('name'), b.get('model'), b.get('serial'),
                b.get('type'), b.get('cabinet'), b.get('responsible'),
                b.get('purchaseDate'), b.get('cost') or 0, b.get('status'),
                b.get('lastTO'), b.get('note')
            )
        )
        conn.commit()
        eid = cur.lastrowid
        conn.close()
        return jsonify({'id': eid}), 201
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'error': 'Инвентарный номер уже существует'}), 400


@app.route('/api/equipment/<int:eid>', methods=['PUT', 'DELETE'])
@login_required
@admin_required
def api_equipment_item(eid):
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM equipment WHERE id=?', (eid,))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})

    b = request.get_json(force=True) or {}
    try:
        conn.execute(
            '''UPDATE equipment SET
               inv_num=?, name=?, model=?, serial=?, type=?, cabinet=?,
               responsible=?, purchase_date=?, cost=?, status=?, last_to=?, note=?
               WHERE id=?''',
            (
                b.get('invNum'), b.get('name'), b.get('model'), b.get('serial'),
                b.get('type'), b.get('cabinet'), b.get('responsible'),
                b.get('purchaseDate'), b.get('cost') or 0, b.get('status'),
                b.get('lastTO'), b.get('note'), eid
            )
        )
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'error': 'Инвентарный номер уже существует'}), 400


# ---------- API: Responsible ----------

@app.route('/api/responsible', methods=['GET', 'POST'])
@login_required
def api_responsible():
    conn = get_db()
    if request.method == 'GET':
        rows = rows_to_list(conn.execute(
            'SELECT id, fio, position, cabinet, phone, email FROM responsible ORDER BY id'
        ).fetchall())
        conn.close()
        return jsonify(rows)

    if session['user'].get('role') != 'admin':
        conn.close()
        return jsonify({'error': 'forbidden'}), 403

    b = request.get_json(force=True) or {}
    cur = conn.execute(
        'INSERT INTO responsible (fio, position, cabinet, phone, email) VALUES (?,?,?,?,?)',
        (b.get('fio'), b.get('position'), b.get('cabinet'), b.get('phone'), b.get('email'))
    )
    conn.commit()
    rid = cur.lastrowid
    conn.close()
    return jsonify({'id': rid}), 201


@app.route('/api/responsible/<int:rid>', methods=['PUT', 'DELETE'])
@login_required
@admin_required
def api_responsible_item(rid):
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM responsible WHERE id=?', (rid,))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    b = request.get_json(force=True) or {}
    conn.execute(
        'UPDATE responsible SET fio=?, position=?, cabinet=?, phone=?, email=? WHERE id=?',
        (b.get('fio'), b.get('position'), b.get('cabinet'), b.get('phone'), b.get('email'), rid)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ---------- API: Maintenance ----------

@app.route('/api/maintenance', methods=['GET', 'POST'])
@login_required
def api_maintenance():
    conn = get_db()
    if request.method == 'GET':
        rows = rows_to_list(conn.execute(
            '''SELECT id, date, inv_num AS invNum, type, description, executor, result, cost
               FROM maintenance ORDER BY date DESC'''
        ).fetchall())
        conn.close()
        return jsonify(rows)

    if session['user'].get('role') != 'admin':
        conn.close()
        return jsonify({'error': 'forbidden'}), 403

    b = request.get_json(force=True) or {}
    cur = conn.execute(
        '''INSERT INTO maintenance (date, inv_num, type, description, executor, result, cost)
           VALUES (?,?,?,?,?,?,?)''',
        (b.get('date'), b.get('invNum'), b.get('type'), b.get('description'),
         b.get('executor'), b.get('result'), b.get('cost') or 0)
    )
    if b.get('type') == 'ТО' and b.get('invNum') and b.get('date'):
        conn.execute(
            'UPDATE equipment SET last_to=? WHERE inv_num=?',
            (b.get('date'), b.get('invNum'))
        )
    conn.commit()
    mid = cur.lastrowid
    conn.close()
    return jsonify({'id': mid}), 201


@app.route('/api/maintenance/<int:mid>', methods=['PUT', 'DELETE'])
@login_required
@admin_required
def api_maintenance_item(mid):
    conn = get_db()
    if request.method == 'DELETE':
        conn.execute('DELETE FROM maintenance WHERE id=?', (mid,))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})
    b = request.get_json(force=True) or {}
    conn.execute(
        '''UPDATE maintenance SET date=?, inv_num=?, type=?, description=?,
           executor=?, result=?, cost=? WHERE id=?''',
        (b.get('date'), b.get('invNum'), b.get('type'), b.get('description'),
         b.get('executor'), b.get('result'), b.get('cost') or 0, mid)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ---------- API: Users (admin) ----------

@app.route('/api/users', methods=['GET', 'POST'])
@login_required
@admin_required
def api_users():
    conn = get_db()
    if request.method == 'GET':
        rows = rows_to_list(conn.execute(
            'SELECT id, login, fio, role, created FROM users ORDER BY id'
        ).fetchall())
        conn.close()
        return jsonify(rows)

    b = request.get_json(force=True) or {}
    login = (b.get('login') or '').strip().lower()
    password = b.get('password') or ''
    fio = (b.get('fio') or '').strip()
    role = b.get('role') or 'user'
    if not login or not fio or len(password) < 6:
        conn.close()
        return jsonify({'error': 'Некорректные данные'}), 400
    try:
        created = datetime.now().strftime('%Y-%m-%d')
        cur = conn.execute(
            'INSERT INTO users (login, password, fio, role, created) VALUES (?,?,?,?,?)',
            (login, password, fio, role, created)
        )
        conn.commit()
        uid = cur.lastrowid
        conn.close()
        return jsonify({'id': uid}), 201
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'error': 'Логин уже занят'}), 400


@app.route('/api/users/<int:uid>', methods=['PUT', 'DELETE'])
@login_required
@admin_required
def api_user_item(uid):
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
    if not user:
        conn.close()
        return jsonify({'error': 'not found'}), 404

    if request.method == 'DELETE':
        if user['login'] == 'admin':
            conn.close()
            return jsonify({'error': 'Нельзя удалить admin'}), 400
        if session['user']['id'] == uid:
            conn.close()
            return jsonify({'error': 'Нельзя удалить себя'}), 400
        conn.execute('DELETE FROM users WHERE id=?', (uid,))
        conn.commit()
        conn.close()
        return jsonify({'ok': True})

    b = request.get_json(force=True) or {}
    fio = (b.get('fio') or user['fio']).strip()
    login = (b.get('login') or user['login']).strip().lower()
    role = b.get('role') or user['role']
    password = b.get('password')
    try:
        if password:
            conn.execute(
                'UPDATE users SET fio=?, login=?, role=?, password=? WHERE id=?',
                (fio, login, role, password, uid)
            )
        else:
            conn.execute(
                'UPDATE users SET fio=?, login=?, role=? WHERE id=?',
                (fio, login, role, uid)
            )
        conn.commit()
        # update session if self
        if session['user']['id'] == uid:
            session['user'] = {'id': uid, 'login': login, 'fio': fio, 'role': role}
        conn.close()
        return jsonify({'ok': True})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'error': 'Логин уже занят'}), 400


# ---------- API: Backup as SQLite DB ----------

@app.route('/api/backups', methods=['GET'])
@login_required
@admin_required
def api_backups_list():
    conn = get_db()
    rows = rows_to_list(conn.execute(
        'SELECT id, filename, created, equipment_count, maintenance_count, size_bytes FROM backup_log ORDER BY id DESC'
    ).fetchall())
    conn.close()
    # also list files on disk
    result = []
    for r in rows:
        path = BACKUP_DIR / r['filename']
        exists = path.exists()
        result.append({
            **r,
            'exists': exists,
            'sizeKb': round((r['size_bytes'] or 0) / 1024, 1)
        })
    return jsonify(result)


@app.route('/api/backups', methods=['POST'])
@login_required
@admin_required
def api_backup_create():
    """Create SQLite .db backup file of current database."""
    now = datetime.now()
    filename = f"Uchet_tehniki_{now.strftime('%Y-%m-%d_%H-%M-%S')}.db"
    dest = BACKUP_DIR / filename

    # Ensure all writes are flushed
    conn = get_db()
    conn.execute('PRAGMA wal_checkpoint(FULL)')
    eq_count = conn.execute('SELECT COUNT(*) AS n FROM equipment').fetchone()['n']
    mt_count = conn.execute('SELECT COUNT(*) AS n FROM maintenance').fetchone()['n']
    conn.close()

    # Copy DB file
    shutil.copy2(str(DB_PATH), str(dest))
    size = dest.stat().st_size

    conn = get_db()
    cur = conn.execute(
        '''INSERT INTO backup_log (filename, created, equipment_count, maintenance_count, size_bytes)
           VALUES (?,?,?,?,?)''',
        (filename, now.isoformat(), eq_count, mt_count, size)
    )
    # keep only last 10
    conn.execute('''
        DELETE FROM backup_log WHERE id NOT IN (
            SELECT id FROM backup_log ORDER BY id DESC LIMIT 10
        )
    ''')
    # remove old files not in log
    keep = {r['filename'] for r in conn.execute('SELECT filename FROM backup_log').fetchall()}
    conn.commit()
    bid = cur.lastrowid
    conn.close()

    for f in BACKUP_DIR.glob('Uchet_tehniki_*.db'):
        if f.name not in keep:
            try:
                f.unlink()
            except OSError:
                pass

    return jsonify({
        'id': bid,
        'filename': filename,
        'created': now.isoformat(),
        'equipment_count': eq_count,
        'maintenance_count': mt_count,
        'sizeKb': round(size / 1024, 1)
    }), 201


@app.route('/api/backups/<int:bid>/download')
@login_required
@admin_required
def api_backup_download(bid):
    conn = get_db()
    row = conn.execute('SELECT * FROM backup_log WHERE id=?', (bid,)).fetchone()
    conn.close()
    if not row:
        return jsonify({'error': 'not found'}), 404
    path = BACKUP_DIR / row['filename']
    if not path.exists():
        return jsonify({'error': 'file missing'}), 404
    return send_file(
        str(path),
        as_attachment=True,
        download_name=row['filename'],
        mimetype='application/x-sqlite3'
    )


@app.route('/api/backups/<int:bid>/restore', methods=['POST'])
@login_required
@admin_required
def api_backup_restore(bid):
    conn = get_db()
    row = conn.execute('SELECT * FROM backup_log WHERE id=?', (bid,)).fetchone()
    conn.close()
    if not row:
        return jsonify({'error': 'not found'}), 404
    path = BACKUP_DIR / row['filename']
    if not path.exists():
        return jsonify({'error': 'file missing'}), 404

    # safety: backup current before restore
    safety_name = f"before_restore_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.db"
    shutil.copy2(str(DB_PATH), str(BACKUP_DIR / safety_name))

    # replace live DB
    shutil.copy2(str(path), str(DB_PATH))
    return jsonify({'ok': True, 'restored': row['filename']})


@app.route('/api/backups/<int:bid>', methods=['DELETE'])
@login_required
@admin_required
def api_backup_delete(bid):
    conn = get_db()
    row = conn.execute('SELECT * FROM backup_log WHERE id=?', (bid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({'error': 'not found'}), 404
    path = BACKUP_DIR / row['filename']
    conn.execute('DELETE FROM backup_log WHERE id=?', (bid,))
    conn.commit()
    conn.close()
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass
    return jsonify({'ok': True})


@app.route('/api/backup/current-db')
@login_required
@admin_required
def api_download_current_db():
    """Download live database as .db file."""
    name = f"Uchet_tehniki_current_{datetime.now().strftime('%Y-%m-%d')}.db"
    return send_file(
        str(DB_PATH),
        as_attachment=True,
        download_name=name,
        mimetype='application/x-sqlite3'
    )


if __name__ == '__main__':
    init_db()
    print('=' * 50)
    print('  ИС «Учёт техники» — SQLite')
    print('  База данных:', DB_PATH)
    print('  Резервные копии:', BACKUP_DIR)
    print('  http://127.0.0.1:5000')
    print('=' * 50)
    app.run(host='127.0.0.1', port=5000, debug=False)
