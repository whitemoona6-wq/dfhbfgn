#!/usr/bin/env python3
"""
Нагрузочное наполнение БД + бенчмарки + оптимизация (индексы, FTS5).
Запуск: python3 bench_and_optimize.py
"""
from __future__ import annotations

import os
import random
import string
import time
from pathlib import Path

# Ensure project root on path
ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)

from werkzeug.security import generate_password_hash

from config import Config
from database import get_db, init_db

# ---------------------------------------------------------------------------
# Config of load
# ---------------------------------------------------------------------------
N_USERS = 1_500
N_PRODUCTS = 2_500          # total target products
N_ORDERS = 2_000
N_ORDER_ITEMS_AVG = 3
N_REVIEWS = 5_000
N_CART = 2_000
N_AUDIT = 5_000

BRANDS = [
    "Logitech", "Razer", "SteelSeries", "Corsair", "HyperX", "Sony",
    "Microsoft", "ASUS", "LG", "Keychron", "Zowie", "Artisan", "BenQ",
    "Samsung", "Glorious", "Pulsar", "Lamzu", "Vaxee",
]
PRODUCT_PREFIXES = [
    "Pro", "Ultra", "Elite", "X", "V", "Max", "Lite", "Wireless",
    "RGB", "Mechanical", "Optical", "Gaming", "Esports", "Tournament",
]


def _rand_name(n: int = 8) -> str:
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))


def seed_load(conn) -> None:
    """Fill tables with realistic volume. Idempotent-ish: skips if already large."""
    c = conn.cursor()

    n_users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    n_products = c.execute("SELECT COUNT(*) FROM products").fetchone()[0]

    if n_users >= N_USERS and n_products >= N_PRODUCTS:
        print(f"[seed] Already loaded (users={n_users}, products={n_products}), skip insert.")
        return

    print("[seed] Generating data...")
    t0 = time.perf_counter()

    # --- users ---
    if n_users < N_USERS:
        need = N_USERS - n_users
        print(f"  users +{need}")
        pwd = generate_password_hash("loadtest123")
        batch = []
        for i in range(need):
            u = f"user_{n_users + i}_{_rand_name(4)}"
            e = f"{u}@example.com"
            batch.append((u, e, pwd, 0, 1, 0, None))
            if len(batch) >= 500:
                c.executemany(
                    "INSERT OR IGNORE INTO users (username, email, password_hash, is_admin, is_active, failed_logins, locked_until) VALUES (?,?,?,?,?,?,?)",
                    batch,
                )
                batch = []
        if batch:
            c.executemany(
                "INSERT OR IGNORE INTO users (username, email, password_hash, is_admin, is_active, failed_logins, locked_until) VALUES (?,?,?,?,?,?,?)",
                batch,
            )
        conn.commit()

    # --- products ---
    n_products = c.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if n_products < N_PRODUCTS:
        need = N_PRODUCTS - n_products
        print(f"  products +{need}")
        cats = [r[0] for r in c.execute("SELECT id FROM categories").fetchall()]
        batch = []
        for i in range(need):
            brand = random.choice(BRANDS)
            name = f"{brand} {random.choice(PRODUCT_PREFIXES)} {_rand_name(5).upper()} {i}"
            desc = f"Описание игрового устройства {name}. Высокое качество, для киберспорта."
            price = round(random.uniform(990, 99990), 2)
            old = price * 1.2 if random.random() < 0.3 else None
            cat = random.choice(cats)
            stock = random.randint(0, 200)
            rating = round(random.uniform(3.5, 5.0), 1)
            features = "RGB, Wireless, Hot-swap"
            batch.append((name, desc, price, old, cat, None, stock, brand, rating, features))
            if len(batch) >= 500:
                c.executemany(
                    """INSERT INTO products (name, description, price, old_price, category_id, image_url, stock, brand, rating, features)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    batch,
                )
                batch = []
        if batch:
            c.executemany(
                """INSERT INTO products (name, description, price, old_price, category_id, image_url, stock, brand, rating, features)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                batch,
            )
        conn.commit()

    user_ids = [r[0] for r in c.execute("SELECT id FROM users").fetchall()]
    product_ids = [r[0] for r in c.execute("SELECT id FROM products").fetchall()]

    # --- orders + order_items ---
    n_orders = c.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    if n_orders < N_ORDERS:
        need = N_ORDERS - n_orders
        print(f"  orders +{need}")
        statuses = ["pending", "processing", "shipped", "delivered", "cancelled"]
        price_map = {r[0]: r[1] for r in c.execute("SELECT id, price FROM products").fetchall()}
        pids = list(price_map.keys())
        for i in range(need):
            uid = random.choice(user_ids)
            total = 0.0
            n_items = random.randint(1, 5)
            items = []
            for _ in range(n_items):
                pid = random.choice(pids)
                qty = random.randint(1, 3)
                price = price_map[pid]
                items.append((pid, qty, price))
                total += qty * price
            c.execute(
                "INSERT INTO orders (user_id, total, status, address, phone) VALUES (?,?,?,?,?)",
                (uid, round(total, 2), random.choice(statuses), f"ул. Тест, д.{random.randint(1,100)}", f"+79{random.randint(100000000,999999999)}"),
            )
            oid = c.lastrowid
            c.executemany(
                "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?,?,?,?)",
                [(oid, p, q, pr) for p, q, pr in items],
            )
            if (i + 1) % 1000 == 0:
                conn.commit()
                print(f"    orders {i+1}/{need}")
        conn.commit()

    # --- reviews ---
    n_rev = c.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    if n_rev < N_REVIEWS:
        need = N_REVIEWS - n_rev
        print(f"  reviews +{need}")
        comments = [
            "Отличный товар!", "Рекомендую", "Сойдёт", "Супер качество",
            "Неплохо за свои деньги", "Ожидал большего", "Топ!",
        ]
        batch = []
        for i in range(need):
            batch.append((
                random.choice(product_ids),
                random.choice(user_ids),
                random.randint(1, 5),
                random.choice(comments),
            ))
            if len(batch) >= 500:
                c.executemany(
                    "INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?,?,?,?)",
                    batch,
                )
                batch = []
        if batch:
            c.executemany(
                "INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?,?,?,?)",
                batch,
            )
        conn.commit()

    # --- cart ---
    n_cart = c.execute("SELECT COUNT(*) FROM cart").fetchone()[0]
    if n_cart < N_CART:
        need = N_CART - n_cart
        print(f"  cart +{need}")
        batch = []
        seen = set()
        for _ in range(need * 2):  # oversample for UNIQUE
            if len(batch) >= need:
                break
            uid = random.choice(user_ids)
            pid = random.choice(product_ids)
            key = (uid, pid)
            if key in seen:
                continue
            seen.add(key)
            batch.append((uid, pid, random.randint(1, 5)))
        c.executemany(
            "INSERT OR IGNORE INTO cart (user_id, product_id, quantity) VALUES (?,?,?)",
            batch,
        )
        conn.commit()

    # --- audit_log ---
    n_audit = c.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0]
    if n_audit < N_AUDIT:
        need = N_AUDIT - n_audit
        print(f"  audit_log +{need}")
        actions = ["login_ok", "login_fail", "csrf_fail", "admin_access_denied", "order_status_change", "product_edit"]
        batch = []
        for i in range(need):
            batch.append((
                random.choice(user_ids) if random.random() > 0.1 else None,
                random.choice(actions),
                f"details {_rand_name(12)}",
                f"192.168.{random.randint(0,255)}.{random.randint(1,254)}",
                "Mozilla/5.0",
                random.choice(["info", "warning", "critical"]),
            ))
            if len(batch) >= 500:
                c.executemany(
                    "INSERT INTO audit_log (user_id, action, details, ip_address, user_agent, severity) VALUES (?,?,?,?,?,?)",
                    batch,
                )
                batch = []
        if batch:
            c.executemany(
                "INSERT INTO audit_log (user_id, action, details, ip_address, user_agent, severity) VALUES (?,?,?,?,?,?)",
                batch,
            )
        conn.commit()

    print(f"[seed] Done in {time.perf_counter() - t0:.2f}s")
    _print_counts(c)


def _print_counts(c) -> None:
    print("  Counts:")
    for t in ("users", "products", "categories", "orders", "order_items", "reviews", "cart", "audit_log"):
        print(f"    {t}: {c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]}")


def list_indexes(conn) -> list:
    return conn.execute(
        "SELECT name, tbl_name, sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL"
    ).fetchall()


def drop_custom_indexes(conn) -> None:
    """Remove indexes we create so BEFORE/AFTER is fair."""
    for name, _, _ in list_indexes(conn):
        if name.startswith("idx_") or name.startswith("fts_"):
            conn.execute(f"DROP INDEX IF EXISTS {name}")
    # FTS table
    conn.execute("DROP TABLE IF EXISTS products_fts")
    conn.commit()


def apply_indexes(conn) -> None:
    """Create performance indexes + FTS5 for search."""
    c = conn.cursor()
    statements = [
        # products
        "CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id)",
        "CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand)",
        "CREATE INDEX IF NOT EXISTS idx_products_rating ON products(rating DESC)",
        "CREATE INDEX IF NOT EXISTS idx_products_price ON products(price)",
        "CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)",
        "CREATE INDEX IF NOT EXISTS idx_products_stock ON products(stock)",
        # reviews
        "CREATE INDEX IF NOT EXISTS idx_reviews_product_id ON reviews(product_id)",
        "CREATE INDEX IF NOT EXISTS idx_reviews_user_id ON reviews(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_reviews_created ON reviews(created_at DESC)",
        # orders
        "CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)",
        # order_items
        "CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON order_items(order_id)",
        "CREATE INDEX IF NOT EXISTS idx_order_items_product_id ON order_items(product_id)",
        # cart
        "CREATE INDEX IF NOT EXISTS idx_cart_user_id ON cart(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_cart_product_id ON cart(product_id)",
        # audit
        "CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action)",
        "CREATE INDEX IF NOT EXISTS idx_audit_user_id ON audit_log(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_audit_action_created ON audit_log(action, created_at DESC)",
        # users
        "CREATE INDEX IF NOT EXISTS idx_users_locked ON users(locked_until)",
        "CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active)",
    ]
    for sql in statements:
        c.execute(sql)

    # FTS5 for catalog search (name, description, brand)
    c.execute("DROP TABLE IF EXISTS products_fts")
    c.execute("""
        CREATE VIRTUAL TABLE products_fts USING fts5(
            name, description, brand,
            content='products', content_rowid='id',
            tokenize='unicode61'
        )
    """)
    c.execute("""
        INSERT INTO products_fts(rowid, name, description, brand)
        SELECT id, name, COALESCE(description,''), COALESCE(brand,'') FROM products
    """)
    # triggers to keep FTS in sync
    for event, op in [
        ("INSERT", "INSERT INTO products_fts(rowid, name, description, brand) VALUES (new.id, new.name, COALESCE(new.description,''), COALESCE(new.brand,''))"),
        ("DELETE", "INSERT INTO products_fts(products_fts, rowid, name, description, brand) VALUES ('delete', old.id, old.name, COALESCE(old.description,''), COALESCE(old.brand,''))"),
        ("UPDATE", """
            INSERT INTO products_fts(products_fts, rowid, name, description, brand) VALUES ('delete', old.id, old.name, COALESCE(old.description,''), COALESCE(old.brand,''));
            INSERT INTO products_fts(rowid, name, description, brand) VALUES (new.id, new.name, COALESCE(new.description,''), COALESCE(new.brand,''))
        """),
    ]:
        c.execute(f"DROP TRIGGER IF EXISTS products_fts_ai_{event.lower()}")
        c.execute(f"""
            CREATE TRIGGER products_fts_ai_{event.lower()} AFTER {event} ON products BEGIN
                {op};
            END
        """)

    conn.commit()
    print("[indexes] Applied:", len(statements), "B-tree + FTS5")


def time_query(conn, label: str, sql: str, params=(), n: int = 20) -> float:
    """Run query n times, return median ms."""
    times = []
    for _ in range(n):
        t0 = time.perf_counter()
        rows = conn.execute(sql, params).fetchall()
        times.append((time.perf_counter() - t0) * 1000)
        _ = len(rows)
    times.sort()
    med = times[len(times) // 2]
    print(f"  {label:55s}  med={med:8.2f} ms  (min={times[0]:.2f} max={times[-1]:.2f})  rows~{len(rows)}")
    return med


def run_benchmarks(conn, tag: str) -> dict:
    print(f"\n=== BENCHMARK [{tag}] ===")
    results = {}

    # 1. Catalog: all products sorted by rating
    results["catalog_all"] = time_query(
        conn, "catalog ORDER BY rating",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           ORDER BY p.rating DESC""",
    )

    # 2. Catalog: filter by category
    slug = conn.execute("SELECT slug FROM categories LIMIT 1").fetchone()[0]
    results["catalog_cat"] = time_query(
        conn, f"catalog category={slug}",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           WHERE c.slug = ? ORDER BY p.rating DESC""",
        (slug,),
    )

    # 3. Catalog: LIKE search (slow path)
    results["catalog_like"] = time_query(
        conn, "catalog LIKE %Logitech%",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           WHERE (p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)
           ORDER BY p.rating DESC""",
        ("%Logitech%", "%Logitech%", "%Logitech%"),
    )

    # 4. Catalog: brand filter
    results["catalog_brand"] = time_query(
        conn, "catalog brand=Razer",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           WHERE p.brand = ? ORDER BY p.rating DESC""",
        ("Razer",),
    )

    # 5. Product detail + reviews
    pid = conn.execute("SELECT id FROM products LIMIT 1").fetchone()[0]
    results["product"] = time_query(
        conn, "product detail JOIN category",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?""",
        (pid,),
    )
    results["reviews"] = time_query(
        conn, "reviews for product JOIN users",
        """SELECT r.*, u.username FROM reviews r JOIN users u ON r.user_id = u.id
           WHERE r.product_id = ? ORDER BY r.created_at DESC""",
        (pid,),
    )

    # 6. Index page top 8
    results["index_top8"] = time_query(
        conn, "index top 8 by rating",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           ORDER BY p.rating DESC LIMIT 8""",
    )

    # 7. Cart for a user
    uid = conn.execute("SELECT user_id FROM cart LIMIT 1").fetchone()
    if uid:
        results["cart"] = time_query(
            conn, "cart items JOIN products",
            """SELECT c.id as cart_id, c.quantity, p.*, (c.quantity * p.price) as subtotal
               FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?""",
            (uid[0],),
        )

    # 8. Admin-style queries
    results["admin_orders"] = time_query(
        conn, "admin orders LIMIT 50",
        """SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id
           ORDER BY o.created_at DESC LIMIT 50""",
    )
    results["admin_audit"] = time_query(
        conn, "admin audit LIMIT 100",
        """SELECT a.*, u.username FROM audit_log a
           LEFT JOIN users u ON a.user_id = u.id
           ORDER BY a.created_at DESC LIMIT 100""",
    )
    results["admin_fail_24h"] = time_query(
        conn, "audit login_fail 24h COUNT",
        """SELECT COUNT(*) FROM audit_log WHERE action='login_fail'
           AND created_at > datetime('now', '-1 day')""",
    )
    results["admin_stats"] = time_query(
        conn, "admin revenue SUM",
        "SELECT COALESCE(SUM(total), 0) FROM orders",
    )
    results["admin_low_stock"] = time_query(
        conn, "products stock < 10 COUNT",
        "SELECT COUNT(*) FROM products WHERE stock < 10",
    )
    results["brands_distinct"] = time_query(
        conn, "SELECT DISTINCT brand",
        "SELECT DISTINCT brand FROM products ORDER BY brand",
    )

    # 9. FTS search (only meaningful AFTER indexes)
    try:
        results["catalog_fts"] = time_query(
            conn, "catalog FTS5 MATCH Logitech",
            """SELECT p.*, c.name as category_name, c.slug as category_slug
               FROM products_fts f
               JOIN products p ON p.id = f.rowid
               JOIN categories c ON p.category_id = c.id
               WHERE products_fts MATCH ?
               ORDER BY p.rating DESC""",
            ("Logitech",),
        )
    except Exception as e:
        print(f"  (FTS not available yet: {e})")

    return results


def optimize_admin_queries_note() -> str:
    return """
Оптимизация кода (рекомендации, уже частично в индексах):

1. admin(): сейчас ~15 отдельных запросов на каждый заход.
   → Можно объединить stats в один SELECT с подзапросами или
     кэшировать stats на 30–60 сек (flask-caching / простой dict+TTL).

2. context_processor cart_count: запрос на КАЖДЫЙ HTML-ответ.
   → Кэшировать в session или g на время запроса; инвалидировать при add/remove.

3. Catalog LIKE '%x%': full scan. После FTS5 — использовать MATCH.

4. get_db() каждый раз открывает новый connection.
   → Для production: connection per-request (g.db) + teardown.

5. SQLite: PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
   ускоряет конкурентные чтения при записи.
"""


def apply_pragmas(conn) -> None:
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA cache_size=-64000")  # 64MB
    conn.execute("PRAGMA foreign_keys=ON")
    conn.commit()
    print("[pragma] WAL + cache 64MB + synchronous=NORMAL")


def main():
    print("=== GameGear load test & optimization ===\n")
    init_db()
    conn = get_db()
    apply_pragmas(conn)

    seed_load(conn)

    # BEFORE: drop our indexes if any
    drop_custom_indexes(conn)
    before = run_benchmarks(conn, "BEFORE indexes")

    # AFTER
    apply_indexes(conn)
    after = run_benchmarks(conn, "AFTER indexes + FTS5")

    print("\n=== SUMMARY (median ms) ===")
    print(f"{'query':55s}  {'before':>10s}  {'after':>10s}  {'speedup':>8s}")
    for k in sorted(set(before) | set(after)):
        b = before.get(k)
        a = after.get(k)
        if b is None or a is None:
            continue
        sp = b / a if a > 0 else float("inf")
        print(f"{k:55s}  {b:10.2f}  {a:10.2f}  {sp:7.1f}x")

    print(optimize_admin_queries_note())

    # Persist optimized catalog helper into a small module for app use
    Path(ROOT / "query_optimized.py").write_text(
        '''"""Optimized query helpers (FTS search, shared patterns)."""
from database import get_db


def catalog_search(search: str | None, category_slug: str | None, brand: str | None, sort: str):
    """Catalog with FTS5 when search is present, else classic filters."""
    conn = get_db()
    params = []
    if search:
        # FTS5: phrase / prefix
        q = """
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products_fts f
            JOIN products p ON p.id = f.rowid
            JOIN categories c ON p.category_id = c.id
            WHERE products_fts MATCH ?
        """
        # Escape FTS special chars simply
        term = search.replace('"', ' ').strip()
        if not term:
            term = '""'
        else:
            # prefix search for partial match
            parts = [f'"{p}"*' if len(p) > 1 else p for p in term.split() if p]
            term = " ".join(parts) if parts else '""'
        params.append(term)
    else:
        q = """
            SELECT p.*, c.name as category_name, c.slug as category_slug
            FROM products p JOIN categories c ON p.category_id = c.id
            WHERE 1=1
        """

    if category_slug:
        q += " AND c.slug = ?"
        params.append(category_slug)
    if brand:
        q += " AND p.brand = ?"
        params.append(brand)

    sort_map = {
        "price_asc": " ORDER BY p.price ASC",
        "price_desc": " ORDER BY p.price DESC",
        "name": " ORDER BY p.name ASC",
    }
    q += sort_map.get(sort, " ORDER BY p.rating DESC")

    products = conn.execute(q, params).fetchall()
    categories = conn.execute("SELECT * FROM categories").fetchall()
    brands = conn.execute("SELECT DISTINCT brand FROM products ORDER BY brand").fetchall()
    conn.close()
    return products, categories, brands
''',
        encoding="utf-8",
    )
    print("[done] query_optimized.py written")
    print("[done] Indexes and FTS5 are in shop.db — restart app to benefit.")
    conn.close()


if __name__ == "__main__":
    main()
