#!/usr/bin/env python3
"""
HTTP-нагрузочные тесты + SQL-профилирование GameGear.

Замер скорости эндпоинтов (p50/p95/p99), concurrent load,
EXPLAIN QUERY PLAN для поиска тормозов.

Примеры:
  python3 load_test.py                  # полный прогон
  python3 load_test.py --sql-only       # только SQL + EXPLAIN
  python3 load_test.py --http-only      # только HTTP
  python3 load_test.py --workers 20 --requests 100
"""
from __future__ import annotations

import argparse
import os
import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

from config import TestingConfig
from database import get_db, init_db


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def pct(sorted_vals: list[float], p: float) -> float:
    if not sorted_vals:
        return 0.0
    idx = min(int(len(sorted_vals) * p / 100), len(sorted_vals) - 1)
    return sorted_vals[idx]


def fmt_ms(ms: float) -> str:
    return f"{ms:8.2f} ms"


def print_table(title: str, rows: list[tuple]) -> None:
    print(f"\n{'=' * 72}")
    print(title)
    print('=' * 72)
    for row in rows:
        print("  " + "  ".join(str(c) for c in row))


# ---------------------------------------------------------------------------
# SQL benchmarks + EXPLAIN
# ---------------------------------------------------------------------------

SQL_QUERIES = [
    (
        "catalog_all_rating",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           ORDER BY p.rating DESC""",
        (),
    ),
    (
        "catalog_category",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           WHERE c.slug = ? ORDER BY p.rating DESC""",
        ("mice",),
    ),
    (
        "catalog_like_search",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           WHERE (p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)
           ORDER BY p.rating DESC""",
        ("%Logitech%", "%Logitech%", "%Logitech%"),
    ),
    (
        "catalog_fts",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products_fts f
           JOIN products p ON p.id = f.rowid
           JOIN categories c ON p.category_id = c.id
           WHERE products_fts MATCH ?
           ORDER BY p.rating DESC""",
        ("Logitech",),
    ),
    (
        "catalog_brand",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           WHERE p.brand = ? ORDER BY p.rating DESC""",
        ("Razer",),
    ),
    (
        "product_detail",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?""",
        (1,),
    ),
    (
        "reviews_for_product",
        """SELECT r.*, u.username FROM reviews r JOIN users u ON r.user_id = u.id
           WHERE r.product_id = ? ORDER BY r.created_at DESC""",
        (1,),
    ),
    (
        "index_top8",
        """SELECT p.*, c.name as category_name, c.slug as category_slug
           FROM products p JOIN categories c ON p.category_id = c.id
           ORDER BY p.rating DESC LIMIT 8""",
        (),
    ),
    (
        "cart_items",
        """SELECT c.id as cart_id, c.quantity, p.*, (c.quantity * p.price) as subtotal
           FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?""",
        (1,),
    ),
    (
        "admin_orders50",
        """SELECT o.*, u.username FROM orders o JOIN users u ON o.user_id = u.id
           ORDER BY o.created_at DESC LIMIT 50""",
        (),
    ),
    (
        "admin_audit100",
        """SELECT a.*, u.username FROM audit_log a
           LEFT JOIN users u ON a.user_id = u.id
           ORDER BY a.created_at DESC LIMIT 100""",
        (),
    ),
    (
        "admin_login_fail_24h",
        """SELECT COUNT(*) FROM audit_log WHERE action='login_fail'
           AND created_at > datetime('now', '-1 day')""",
        (),
    ),
    (
        "admin_revenue",
        "SELECT COALESCE(SUM(total), 0) FROM orders",
        (),
    ),
    (
        "admin_low_stock",
        "SELECT COUNT(*) FROM products WHERE stock < 10",
        (),
    ),
    (
        "distinct_brands",
        "SELECT DISTINCT brand FROM products ORDER BY brand",
        (),
    ),
]


def run_sql_bench(n: int = 30) -> list[dict]:
    conn = get_db()
    # warm-up
    try:
        conn.execute("SELECT 1 FROM products_fts LIMIT 1").fetchone()
    except Exception:
        pass

    results = []
    print("\n--- SQL timing (median of {} runs) ---".format(n))
    print(f"{'query':30s} {'med':>10s} {'p95':>10s} {'min':>10s} {'max':>10s} {'rows':>6s}")

    for name, sql, params in SQL_QUERIES:
        times = []
        rows_n = 0
        skip = False
        for _ in range(n):
            try:
                t0 = time.perf_counter()
                rows = conn.execute(sql, params).fetchall()
                times.append((time.perf_counter() - t0) * 1000)
                rows_n = len(rows)
            except Exception as e:
                print(f"  {name:30s}  SKIP ({e})")
                skip = True
                break
        if skip:
            continue
        times.sort()
        med = times[len(times) // 2]
        p95 = pct(times, 95)
        results.append({
            "name": name, "med": med, "p95": p95,
            "min": times[0], "max": times[-1], "rows": rows_n,
        })
        flag = " << SLOW" if med > 5 else ("  slow" if med > 2 else "")
        print(f"{name:30s} {fmt_ms(med)} {fmt_ms(p95)} {fmt_ms(times[0])} {fmt_ms(times[-1])} {rows_n:6d}{flag}")

    conn.close()
    return results


def run_explain() -> None:
    conn = get_db()
    print("\n--- EXPLAIN QUERY PLAN (поиск full scan / missing index) ---")
    bottlenecks = []
    for name, sql, params in SQL_QUERIES:
        try:
            plan = conn.execute("EXPLAIN QUERY PLAN " + sql, params).fetchall()
        except Exception as e:
            print(f"\n[{name}] SKIP: {e}")
            continue
        lines = [dict(r) if hasattr(r, "keys") else r for r in plan]
        # sqlite Row: id, parent, notused, detail
        details = []
        for r in plan:
            d = r["detail"] if "detail" in r.keys() else str(r)
            details.append(d)
        has_scan = any("SCAN" in d and "USING INDEX" not in d and "COVERING" not in d for d in details)
        # FTS match is expected SCAN on virtual table
        if "fts" in name.lower():
            has_scan = False
        print(f"\n[{name}]")
        for d in details:
            mark = " ⚠" if ("SCAN" in d and "INDEX" not in d and "fts" not in name.lower()) else ""
            print(f"  {d}{mark}")
        if has_scan:
            bottlenecks.append(name)
    conn.close()
    if bottlenecks:
        print("\n⚠ Возможные full-scan / без индекса:")
        for b in bottlenecks:
            print(f"  - {b}")
    else:
        print("\n✓ Явных full-scan без индекса не найдено (или только ожидаемые).")


# ---------------------------------------------------------------------------
# HTTP load via Flask test client
# ---------------------------------------------------------------------------

def make_app():
    from app import create_app
    app = create_app(TestingConfig)
    app.config["TESTING"] = True
    # disable rate limits noise in security if any
    return app


def http_endpoints(client) -> list[tuple[str, str, dict]]:
    """List of (label, path, kwargs for client.get)."""
    # discover a product id
    conn = get_db()
    pid = conn.execute("SELECT id FROM products LIMIT 1").fetchone()[0]
    conn.close()
    return [
        ("GET /", "/", {}),
        ("GET /catalog", "/catalog", {}),
        ("GET /catalog?q=Logitech", "/catalog", {"query_string": {"q": "Logitech"}}),
        ("GET /catalog?category=mice", "/catalog", {"query_string": {"category": "mice"}}),
        ("GET /catalog?brand=Razer", "/catalog", {"query_string": {"brand": "Razer"}}),
        ("GET /catalog?sort=price_asc", "/catalog", {"query_string": {"sort": "price_asc"}}),
        (f"GET /product/{pid}", f"/product/{pid}", {}),
        ("GET /login", "/login", {}),
        ("GET /register", "/register", {}),
        ("GET /cart (anon→redirect)", "/cart", {}),
    ]


def time_one(client, path: str, kwargs: dict) -> float:
    t0 = time.perf_counter()
    client.get(path, **kwargs)
    return (time.perf_counter() - t0) * 1000


def run_http_sequential(app, repeats: int = 20) -> list[dict]:
    results = []
    print(f"\n--- HTTP sequential ({repeats} req / endpoint) ---")
    print(f"{'endpoint':35s} {'med':>10s} {'p95':>10s} {'p99':>10s} {'max':>10s}")
    with app.test_client() as client:
        endpoints = http_endpoints(client)
        for label, path, kwargs in endpoints:
            times = [time_one(client, path, kwargs) for _ in range(repeats)]
            times.sort()
            med, p95, p99 = times[len(times) // 2], pct(times, 95), pct(times, 99)
            results.append({"name": label, "med": med, "p95": p95, "p99": p99, "max": times[-1]})
            flag = " << SLOW" if med > 50 else ("  slow" if med > 20 else "")
            print(f"{label:35s} {fmt_ms(med)} {fmt_ms(p95)} {fmt_ms(p99)} {fmt_ms(times[-1])}{flag}")
    return results


def run_http_concurrent(app, workers: int = 10, requests_per_ep: int = 50) -> list[dict]:
    """Fire concurrent GETs against the same test client is not thread-safe.
    Use one client per worker.
    """
    print(f"\n--- HTTP concurrent (workers={workers}, req/ep={requests_per_ep}) ---")
    print(f"{'endpoint':35s} {'med':>10s} {'p95':>10s} {'p99':>10s} {'rps':>8s} {'err':>5s}")

    # Build path list outside client
    conn = get_db()
    pid = conn.execute("SELECT id FROM products LIMIT 1").fetchone()[0]
    conn.close()
    endpoints = [
        ("GET /", "/", {}),
        ("GET /catalog", "/catalog", {}),
        ("GET /catalog?q=Logitech", "/catalog", {"query_string": {"q": "Logitech"}}),
        ("GET /catalog?category=mice", "/catalog", {"query_string": {"category": "mice"}}),
        (f"GET /product/{pid}", f"/product/{pid}", {}),
        ("GET /login", "/login", {}),
    ]

    results = []
    for label, path, kwargs in endpoints:
        times: list[float] = []
        errors = 0

        def worker(_i: int) -> float | None:
            # each thread gets its own client
            with app.test_client() as c:
                try:
                    t0 = time.perf_counter()
                    resp = c.get(path, **kwargs)
                    ms = (time.perf_counter() - t0) * 1000
                    if resp.status_code >= 500:
                        return None
                    return ms
                except Exception:
                    return None

        t_wall0 = time.perf_counter()
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(worker, i) for i in range(requests_per_ep)]
            for f in as_completed(futs):
                v = f.result()
                if v is None:
                    errors += 1
                else:
                    times.append(v)
        wall = time.perf_counter() - t_wall0
        if not times:
            print(f"{label:35s}  ALL FAILED  errors={errors}")
            continue
        times.sort()
        med, p95, p99 = times[len(times) // 2], pct(times, 95), pct(times, 99)
        rps = len(times) / wall if wall > 0 else 0
        results.append({
            "name": label, "med": med, "p95": p95, "p99": p99,
            "rps": rps, "errors": errors,
        })
        flag = " << SLOW" if p95 > 100 else ("  slow" if p95 > 50 else "")
        print(f"{label:35s} {fmt_ms(med)} {fmt_ms(p95)} {fmt_ms(p99)} {rps:7.1f} {errors:5d}{flag}")
    return results


# ---------------------------------------------------------------------------
# Bottleneck report
# ---------------------------------------------------------------------------

def report_bottlenecks(sql_res: list[dict], http_seq: list[dict], http_conc: list[dict]) -> None:
    print("\n" + "=" * 72)
    print("ОТЧЁТ: тормоза и рекомендации")
    print("=" * 72)

    slow_sql = [r for r in sql_res if r["med"] > 2.0]
    slow_http = [r for r in (http_seq or []) if r["med"] > 20.0]
    slow_conc = [r for r in (http_conc or []) if r["p95"] > 50.0]

    if slow_sql:
        print("\nSQL (med > 2 ms):")
        for r in sorted(slow_sql, key=lambda x: -x["med"]):
            print(f"  • {r['name']}: med={r['med']:.2f} ms  p95={r['p95']:.2f} ms  rows={r['rows']}")
        print("  → Проверьте индексы / FTS (python3 bench_and_optimize.py)")
        print("  → catalog_all без LIMIT отдаёт все товары — нужна пагинация")
    else:
        print("\n✓ SQL: критичных тормозов (>2 ms median) нет")

    if slow_http:
        print("\nHTTP sequential (med > 20 ms):")
        for r in sorted(slow_http, key=lambda x: -x["med"]):
            print(f"  • {r['name']}: med={r['med']:.2f} ms  p95={r['p95']:.2f} ms")
    else:
        print("\n✓ HTTP sequential: всё < 20 ms median")

    if slow_conc:
        print("\nHTTP concurrent (p95 > 50 ms):")
        for r in sorted(slow_conc, key=lambda x: -x["p95"]):
            print(f"  • {r['name']}: p95={r['p95']:.2f} ms  rps={r.get('rps', 0):.1f}")
        print("  → SQLite под concurrent write упрётся в блокировки; для prod — PostgreSQL")
        print("  → WAL уже включён; увеличьте cache_size при нехватке RAM")
    else:
        print("\n✓ HTTP concurrent: p95 в норме")

    print("""
Типичные узкие места в этом проекте:
  1. /catalog без пагинации при 10k+ товаров
  2. LIKE '%x%' вместо FTS5 (если products_fts нет)
  3. admin.html — 15 отдельных COUNT/SELECT на один запрос
  4. cart_count в context_processor на каждый HTML (кэш в g уже есть)
  5. Новый sqlite-connect на каждый get_db() — для prod: g.db + teardown
""")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def _use_fast_db_copy() -> str:
    """Copy shop.db to /tmp for realistic timings (some mounts are slow for SQLite)."""
    import shutil
    from config import Config
    src = Config.DATABASE
    dst = "/tmp/gamegear_loadtest.db"
    shutil.copy2(src, dst)
    for suffix in ("-wal", "-shm"):
        pth = dst + suffix
        if os.path.exists(pth):
            try:
                os.remove(pth)
            except OSError:
                pass
    Config.DATABASE = dst
    TestingConfig.DATABASE = dst
    return dst


def main():
    parser = argparse.ArgumentParser(description="GameGear load test & bottleneck finder")
    parser.add_argument("--sql-only", action="store_true")
    parser.add_argument("--http-only", action="store_true")
    parser.add_argument("--workers", type=int, default=10)
    parser.add_argument("--requests", type=int, default=40, help="requests per endpoint (concurrent)")
    parser.add_argument("--repeats", type=int, default=20, help="sequential repeats per endpoint")
    parser.add_argument("--no-explain", action="store_true")
    parser.add_argument("--keep-db-path", action="store_true",
                        help="Do not copy DB to /tmp (slower on network/FUSE mounts)")
    args = parser.parse_args()

    print("GameGear load test")
    if not args.keep_db_path:
        db_path = _use_fast_db_copy()
        print(f"DB (fast copy): {db_path}")
    else:
        print("DB: shop.db (original path)")
    init_db()

    conn = get_db()
    print("Counts:", {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                      for t in ("users", "products", "orders", "reviews", "audit_log")})
    conn.close()

    sql_res: list[dict] = []
    http_seq: list[dict] = []
    http_conc: list[dict] = []

    if not args.http_only:
        sql_res = run_sql_bench()
        if not args.no_explain:
            run_explain()

    if not args.sql_only:
        app = make_app()
        http_seq = run_http_sequential(app, repeats=args.repeats)
        http_conc = run_http_concurrent(app, workers=args.workers, requests_per_ep=args.requests)

    report_bottlenecks(sql_res, http_seq, http_conc)
    print("\nГотово. Для наполнения БД и индексов: python3 bench_and_optimize.py")


if __name__ == "__main__":
    main()
