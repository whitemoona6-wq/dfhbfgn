# Внешние интеграции GameGear

## Оплата (Payment Provider)

Абстракция в `integrations/payments.py`.

| Провайдер | Env | Назначение |
|-----------|-----|------------|
| **mock** (по умолчанию) | `PAYMENT_PROVIDER=mock` | Локальная имитация без сети |
| **yookassa** | `PAYMENT_PROVIDER=yookassa` + ключи | Реальный API ЮKassa |

### Переменные окружения

```bash
export PAYMENT_PROVIDER=mock          # или yookassa
export YOOKASSA_SHOP_ID=...
export YOOKASSA_SECRET_KEY=...
export PAYMENT_RETURN_URL=https://your.domain/payment/return
export PAYMENT_WEBHOOK_SECRET=optional_hmac_secret
```

### Поток

1. Checkout создаёт заказ `status=awaiting_payment`, вызывает `create_payment`.
2. Пользователь уходит на `confirmation_url` (mock → `/payment/return?...&mock=1`).
3. Return URL / webhook обновляют `payment_status`; при `succeeded` заказ → `processing`.

### Эндпоинты

| URL | Метод | Описание |
|-----|-------|----------|
| `/payment/return` | GET | Возврат пользователя после оплаты |
| `/api/webhooks/payment` | POST | Webhook провайдера |
| `/api/webhooks/payment/mock-succeed/<id>` | POST | Dev: принудительно succeeded (только mock) |

Пример webhook (mock):

```bash
curl -X POST http://127.0.0.1:5000/api/webhooks/payment \
  -H 'Content-Type: application/json' \
  -d '{"event":"payment.updated","payment_id":"mock_xxx","status":"succeeded","order_id":1}'
```

## Уведомления (Telegram)

`integrations/notifications.py` — опционально.

```bash
export TELEGRAM_BOT_TOKEN=123456:ABC...
export TELEGRAM_CHAT_ID=-100...
export NOTIFY_ENABLED=1
```

События: новый заказ, смена статуса оплаты.

## Оптимизации (кратко)

- Индексы + FTS5, пагинация каталога (24/стр)
- Один connection на HTTP-запрос (`g._db` + `teardown`)
- Admin stats — один batched SELECT вместо ~11
- Заказы пользователя — один `IN (...)` вместо N+1
- WAL PRAGMA только при init, не на каждый connect
- `cart_count` кэшируется в `g` на запрос

Замеры: `python3 load_test.py` · seed: `python3 bench_and_optimize.py`
