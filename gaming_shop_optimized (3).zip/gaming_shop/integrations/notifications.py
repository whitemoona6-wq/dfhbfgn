"""External notifications: Telegram Bot API (optional).

Env
---
TELEGRAM_BOT_TOKEN=123:ABC
TELEGRAM_CHAT_ID=-100...
NOTIFY_ENABLED=1
"""
from __future__ import annotations

import json
import logging
import os
from typing import Optional
from urllib import error, request

logger = logging.getLogger(__name__)


def _enabled() -> bool:
    if not os.environ.get("TELEGRAM_BOT_TOKEN"):
        return False
    if not os.environ.get("TELEGRAM_CHAT_ID"):
        return False
    val = os.environ.get("NOTIFY_ENABLED", "1").strip().lower()
    return val in ("1", "true", "yes", "on")


def send_telegram(text: str, chat_id: Optional[str] = None) -> bool:
    """Send a plain-text message via Telegram Bot API. Returns True on success."""
    if not _enabled() and not (chat_id and os.environ.get("TELEGRAM_BOT_TOKEN")):
        logger.debug("Telegram notify skipped (not configured)")
        return False
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    chat = chat_id or os.environ["TELEGRAM_CHAT_ID"]
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = json.dumps({
        "chat_id": chat,
        "text": text[:4000],
        "disable_web_page_preview": True,
    }).encode("utf-8")
    req = request.Request(url, data=payload, method="POST")
    req.add_header("Content-Type", "application/json")
    try:
        with request.urlopen(req, timeout=10) as resp:
            ok = resp.status == 200
            if not ok:
                logger.warning("Telegram status %s", resp.status)
            return ok
    except error.URLError as e:
        logger.warning("Telegram notify failed: %s", e)
        return False


def notify_order_created(
    *,
    order_id: int,
    total: float,
    username: str,
    payment_status: str = "pending",
) -> bool:
    text = (
        f"🛒 Новый заказ #{order_id}\n"
        f"Пользователь: {username}\n"
        f"Сумма: {total:,.0f} ₽\n"
        f"Оплата: {payment_status}"
    )
    return send_telegram(text)


def notify_payment_status(
    *,
    order_id: int,
    payment_id: str,
    status: str,
) -> bool:
    emoji = "✅" if status == "succeeded" else "⏳" if status in ("pending", "waiting_for_capture") else "❌"
    text = (
        f"{emoji} Оплата заказа #{order_id}\n"
        f"payment_id: {payment_id}\n"
        f"status: {status}"
    )
    return send_telegram(text)
