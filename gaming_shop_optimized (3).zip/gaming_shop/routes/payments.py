"""Payment pages + webhook for external payment provider."""
from __future__ import annotations

import logging

from flask import Blueprint, current_app, flash, redirect, request, url_for, jsonify
from flask_login import login_required, current_user

from database import get_db
from integrations.payments import get_payment_provider
from integrations.notifications import notify_payment_status
from security import log_audit

logger = logging.getLogger(__name__)
payments_bp = Blueprint("payments", __name__)


def _apply_payment_status(conn, order_id: int, payment_id: str, status: str) -> None:
    """Update order payment fields; mark order paid when succeeded."""
    conn.execute(
        "UPDATE orders SET payment_id = ?, payment_status = ? WHERE id = ?",
        (payment_id, status, order_id),
    )
    if status == "succeeded":
        conn.execute(
            "UPDATE orders SET status = CASE WHEN status IN ('pending','awaiting_payment') "
            "THEN 'processing' ELSE status END WHERE id = ?",
            (order_id,),
        )
    elif status in ("canceled", "failed"):
        conn.execute(
            "UPDATE orders SET status = CASE WHEN status = 'awaiting_payment' "
            "THEN 'cancelled' ELSE status END WHERE id = ?",
            (order_id,),
        )
    conn.commit()


@payments_bp.route("/payment/return")
@login_required
def payment_return():
    """User returns from payment provider (or mock confirm page)."""
    payment_id = (request.args.get("payment_id") or "").strip()
    order_id_raw = request.args.get("order_id")
    mock = request.args.get("mock")

    if not payment_id:
        flash("Нет идентификатора платежа", "warning")
        return redirect(url_for("cart.orders"))

    provider = get_payment_provider()

    # Mock: clicking return URL simulates successful payment
    if mock and provider.name == "mock" and hasattr(provider, "mark_succeeded"):
        provider.mark_succeeded(payment_id)

    result = provider.get_payment(payment_id)
    conn = get_db()

    order = None
    if order_id_raw:
        try:
            oid = int(order_id_raw)
            order = conn.execute(
                "SELECT * FROM orders WHERE id = ? AND user_id = ?",
                (oid, current_user.id),
            ).fetchone()
        except (TypeError, ValueError):
            order = None

    if not order and result.raw:
        meta = (result.raw or {}).get("metadata") or {}
        oid = meta.get("order_id")
        if oid:
            try:
                order = conn.execute(
                    "SELECT * FROM orders WHERE id = ? AND user_id = ?",
                    (int(oid), current_user.id),
                ).fetchone()
            except (TypeError, ValueError):
                pass

    if order and result.ok:
        _apply_payment_status(conn, order["id"], payment_id, result.status)
        log_audit(
            "payment_return",
            f"order={order['id']} payment={payment_id} status={result.status}",
        )
        notify_payment_status(
            order_id=order["id"], payment_id=payment_id, status=result.status,
        )
        if result.status == "succeeded":
            flash(f"Оплата заказа №{order['id']} прошла успешно", "success")
        elif result.status in ("pending", "waiting_for_capture"):
            flash("Платёж ещё обрабатывается", "info")
        else:
            flash(f"Статус оплаты: {result.status}", "warning")
    else:
        flash("Не удалось подтвердить оплату", "danger")

    conn.close()
    return redirect(url_for("cart.orders"))


@payments_bp.route("/api/webhooks/payment", methods=["POST"])
def payment_webhook():
    """External provider webhook (YooKassa / mock). No session auth — signature check."""
    body = request.get_data()
    provider = get_payment_provider()
    headers = {k: v for k, v in request.headers.items()}

    if not provider.verify_webhook(body, headers):
        log_audit("payment_webhook_reject", "invalid signature", severity="warning")
        return jsonify({"ok": False, "error": "invalid signature"}), 403

    try:
        payload = provider.parse_webhook(body)
    except Exception as e:
        logger.exception("webhook parse")
        return jsonify({"ok": False, "error": str(e)}), 400

    payment_id = payload.get("payment_id")
    status = payload.get("status")
    order_id = payload.get("order_id")

    if not payment_id or not status:
        return jsonify({"ok": False, "error": "missing fields"}), 400

    conn = get_db()
    order = None
    if order_id:
        try:
            order = conn.execute(
                "SELECT * FROM orders WHERE id = ?", (int(order_id),)
            ).fetchone()
        except (TypeError, ValueError):
            order = None
    if not order:
        order = conn.execute(
            "SELECT * FROM orders WHERE payment_id = ?", (payment_id,)
        ).fetchone()

    if not order:
        conn.close()
        # Acknowledge to avoid retries for unknown orders
        return jsonify({"ok": True, "matched": False})

    _apply_payment_status(conn, order["id"], payment_id, status)
    log_audit(
        "payment_webhook",
        f"order={order['id']} payment={payment_id} status={status}",
        severity="info",
    )
    notify_payment_status(
        order_id=order["id"], payment_id=payment_id, status=status,
    )
    conn.close()
    return jsonify({"ok": True, "order_id": order["id"], "status": status})


@payments_bp.route("/api/webhooks/payment/mock-succeed/<payment_id>", methods=["POST"])
def mock_succeed(payment_id):
    """Dev helper: force mock payment to succeeded (disabled unless PAYMENT_PROVIDER=mock)."""
    provider = get_payment_provider()
    if provider.name != "mock":
        return jsonify({"ok": False, "error": "not mock"}), 403
    if hasattr(provider, "mark_succeeded"):
        provider.mark_succeeded(payment_id)
    conn = get_db()
    order = conn.execute(
        "SELECT * FROM orders WHERE payment_id = ?", (payment_id,)
    ).fetchone()
    if order:
        _apply_payment_status(conn, order["id"], payment_id, "succeeded")
        notify_payment_status(
            order_id=order["id"], payment_id=payment_id, status="succeeded",
        )
    conn.close()
    return jsonify({"ok": True, "payment_id": payment_id})
